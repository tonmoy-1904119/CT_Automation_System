// // swagger.ts

// import swaggerJsdoc from 'swagger-jsdoc'

// const options = {
//   definition: {
//     openapi: '3.0.0',
//     info: {
//       title: 'Class test & attendance automation api documentation',
//       version: '1.0.0',
//       description: 'This is a software engineering sessional project',
//     },
//     servers: [{ url: 'http://localhost:5000', description: '' }],
//   },

//   apis: [`${__dirname}/Routes/*.routes.ts`, `${__dirname}/../dist/*.routes.js`], // Path to the API routes
// }

// const swagger = swaggerJsdoc(options)

// export default swagger
