export type Role = 'student' | 'teacher'
