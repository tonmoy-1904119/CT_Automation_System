export type IAttendance = {
  studentId: string
  present: boolean
}
