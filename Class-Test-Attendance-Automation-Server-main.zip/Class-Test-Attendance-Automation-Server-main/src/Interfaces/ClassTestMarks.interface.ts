export type ExcelMark = {
  studentId: string
  marks: string
}
