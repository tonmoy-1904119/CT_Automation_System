-- DropIndex
DROP INDEX "Marks_classTestId_key";
