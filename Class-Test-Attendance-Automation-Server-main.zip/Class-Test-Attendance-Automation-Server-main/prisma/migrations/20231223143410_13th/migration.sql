-- AlterTable
ALTER TABLE "Class_tests" ADD COLUMN     "evaluated" BOOLEAN NOT NULL DEFAULT false;
