export interface TeacherLogin {
  teacherId: string;
  password: string;
}
