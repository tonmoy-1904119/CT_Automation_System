export const baseURL = "https://class-test-attendance-automation-server.onrender.com/api/v1";
